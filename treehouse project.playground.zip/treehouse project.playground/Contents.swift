let player1: [String: Any] = ["name": "joe smith", "height": "42", "experience": "yes", "guardian": "jim and jan smith"]
let player2: [String: Any] = ["name": "Jill Tanner", "height": "36", "experience": "yes", "guardian": "Clara Tanner"]
let player3: [String: Any] = ["name": "Bill Bon", "height": "43", "experience": "yes", "guardian": "Sara and Jenny Bon"]
let player4: [String: Any] = ["name": "Eva Gordon", "height": "45", "experience": "no", "guardian": "Wendy and Mike Gordon"]
let player5: [String: Any] = ["name": "Matt Gill", "height": "40", "experience": "no", "guardian": "Charles and Sylvia Gill"]
let player6: [String: Any] = ["name": "Kimmy Stein", "height": "41", "experience": "no", "guardian": "Bill and Hillary Stein"]
let player7: [String: Any] = ["name": "Sammy Adams", "height": "45", "experience": "no", "guardian": "Jeff Adams"]
let player8: [String: Any] = ["name": "Karl Saygan", "height": "42", "experience": "yes", "guardian": "Heather Bledsoe"]
let player9: [String: Any] = ["name": "Suzane Greenberg", "height": "44", "experience": "yes", "guardian": "Henrietta Dumas"]
let player10: [String: Any] = ["name": "Sal Dali", "height": "41", "experience": "no", "guardian": "Gala Dali"]
let player11: [String: Any] = ["name": "Joe Kavalier", "height": "39", "experience": "no", "guardian": "Sam and Elaine Kavalier"]
let player12: [String: Any] = ["name": "Ben Finkelstein", "height": "44", "experience": "no", "guardian": "Aaron and Jill Finkelstein"]
let player13: [String: Any] = ["name": "Diego Soto", "height": "41", "experience": "yes", "guardian": "Robin and Sarika Soto"]
let player14: [String: Any] = ["name": "Chloe Alaska", "height": "47", "experience": "no", "guardian": "David and Jamie Alaska"]
let player15: [String: Any] = ["name": "Arnold Willis", "height": "43", "experience": "no", "guardian": "Claire Willis"]
let player16: [String: Any] = ["name": "Phillip Helm", "height": "44", "experience": "yes", "guardian": "Thomas Helm and Eva Jones"]
let player17: [String: Any] = ["name": "Les Clay", "height": "42", "experience": "yes", "guardian": "Wynonna Brown"]
let player18: [String: Any] = ["name": "Herschel Krustofski", "height": "45", "experience": "yes", "guardian": "Hyman and Rachel Krustofski"]

//the dictionaries of experience level of the player
var experiencedPlayers: [[String: Any]] = []
var nonExperiencedPlayers: [[String: Any]] = []
//the teams
var teamDragons: [[String: Any]] = []
var teamSharks: [[String: Any]] = []
var teamRaptors: [[String: Any]] = []
//all of the players in one dictionary
var theLeague: [[String: Any]] = [player1,player2,player3,player4,player5,player6,player7,player8,player9,player10,player11,player12,player13,player14,player15,player16,player17,player18]
// the experience of each player
for player in theLeague {
    if player["experience"] as! String == "yes" {
        experiencedPlayers.append(player)
    } else if player["experience"] as! String == "no"{
        nonExperiencedPlayers.append(player)
    }
}
// putting experienced players in the teams
for player in experiencedPlayers {
    if teamDragons.count < teamSharks.count {
        teamDragons.append(player)
    } else if teamSharks.count < teamRaptors.count {
        teamSharks.append(player)
    } else {
        teamRaptors.append(player)
    }
}
// putting non experienced players in the teams
for player in nonExperiencedPlayers {
    if teamDragons.count < teamSharks.count {
        teamDragons.append(player)
    } else if teamSharks.count < teamRaptors.count {
        teamSharks.append(player)
    } else {
        teamRaptors.append(player)
    }
}


// the letters

for player in teamDragons {
    print("Hello \(player["guardian"]!),we would like to tell you that \(player["name"]!) joined team Dragons. we are waiting you on the first team practice on march 17th at 1pm, thank you!")
}
for player in teamSharks {
    print("Hello \(player["guardian"]!),we would like to tell you that \(player["name"]!) joined team Sharks. we are waiting you on the first team practice on march 17th at 3pm, thank you!")
}
for player in teamRaptors {
    print("Hello \(player["guardian"]!),we would like to tell you that \(player["name"]!) joined team Raptors. we are waiting you on the first team practice on march 18th at 1pm, thank you!")
}
